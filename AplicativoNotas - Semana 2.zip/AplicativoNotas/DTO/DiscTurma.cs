﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class DiscTurma
    {
        private int DisciplinaId { get; set; }
        private int TurmaId { get; set; }
    }
}
