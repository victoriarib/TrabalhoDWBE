﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Matricula
    {
        private int Id { get; set; }
        private string Tipo { get; set; }

    }
}
