﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Lancamentos
    {
        private int Id { get; set; }
        private string DescLancamento { get; set; }
        private int AlunoId { get; set; }
        private int ProfessorId { get; set; }
        private string Tipo { get; set; }

    }
}
