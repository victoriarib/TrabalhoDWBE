﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Aluno
    {
        private int Id { get; set; }
        private string nome { get; set; }
        private int CursoId { get; set; }
    }
}
