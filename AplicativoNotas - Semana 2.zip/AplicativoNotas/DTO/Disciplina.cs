﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Disciplina
    {
        private int Id { get; set; }
        private string DescDisciplina { get; set; }
        private List<DiscTurma> discTurmas { get; }
    }
}
