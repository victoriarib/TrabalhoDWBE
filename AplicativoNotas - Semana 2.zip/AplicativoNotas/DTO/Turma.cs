﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Turma
    {
        private int Id { get; set; }
        private int CursoId { get; set; }
        private int ProfessorId { get; set; }
        private int DisciplinaId { get; set; }
        private List<Aluno> alunos { get; }
        private List<DiscTurma> discTurmas { get; }
    }
}
