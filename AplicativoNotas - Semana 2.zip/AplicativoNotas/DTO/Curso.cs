﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Curso
    {
        private int Id { get; set; }
        private string DescDisciplina { get; set; }
        private List<Aluno> alunos { get;  }
        private List<Disciplina> disciplinas { get;  }

    }
}
