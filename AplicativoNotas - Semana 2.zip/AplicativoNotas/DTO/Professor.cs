﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Professor
    {
        private int id { get; set; }
        private string nome { get; set; }
        private List<Disciplina> disciplinas { get;  }
        private Matricula matricula { get; set; }
    }
}
