﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    class Login
    {
        public int Id { get; set; }
        private string usuario { get; set; }
        private string senha { get; set; }
        private int MatriculaId { get; set; }
    }
}
